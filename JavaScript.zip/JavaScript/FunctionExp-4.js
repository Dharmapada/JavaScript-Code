const myArray = [200,400,600,800]

function arrayFunction(getArray) {
    return getArray[2]
}

console.log(arrayFunction(myArray));

console.log(arrayFunction([467,234,345,456]));