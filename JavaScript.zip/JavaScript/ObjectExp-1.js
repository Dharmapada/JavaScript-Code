
//Object Literal

const candidateOne = {
    name:"Ramaswamy",
    politicalParty:"Republican",
    country:"USA"
}

console.log(candidateOne.name);
console.log(candidateOne["name"]);
//We can get our object data lite the above two example.


//We can also declare Object like this.
const candidateTwo = {
    "name":"Trump",
    "politicaParty":"Republican",
    "country":"USA"
}

console.log(candidateTwo["name"]);