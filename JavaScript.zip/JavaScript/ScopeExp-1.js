let a = 10;
const b = 20;
var c = 30;

if(true){
     a = 100;
    //  b = 200;
    var c = 300;
}

console.log(a);
console.log(b);
console.log(c);


